<?php
/**
 * @package WP Static HTML Output
 *
 * Copyright (c) 2011 Leon Stafford
 */

/**
 * WP Static HTML Output exceptions class
 */
class StaticHtmlOutput_Exception extends Exception
{}