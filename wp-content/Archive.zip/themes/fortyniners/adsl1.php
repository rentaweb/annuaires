<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- haut gauche jeans -->
<ins class="adsbygoogle"
     style="display:inline-block;width:336px;height:280px"
     data-ad-client="ca-pub-8292274258913498"
     data-ad-slot="6208357743"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>